from ultralytics import YOLO
import cv2

# Load the YOLO model
model = YOLO("best.pt")

YOLO.save_dir = "static/images"


# Define a Gradio function to make predictions on an uploaded image
def predict_image(input_image):
    # Make predictions using the YOLO model
    print(input_image)
    image = cv2.imread(input_image)
    results_image = model(image, save=True)
    for r in results_image:
        im_array = r.plot(font_size=0.2, labels=False)
    cv2.imwrite("runs/segment/predict/image0.jpg", im_array)
