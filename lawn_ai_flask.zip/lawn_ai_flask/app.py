from flask import Flask, render_template, request, redirect
import pandas as pd
from regrid import get_image
from yolo_detection import predict_image
import shutil
import os

app = Flask(__name__)


@app.route("/")
def index():
    try:
        shutil.rmtree("runs")
        os.remove("static/images/image0.jpg")
        shutil.rmtree("static/images/image0.jpg")
    except:
        pass
    return render_template("start.html")


@app.route("/submit", methods=["GET", "POST"])
def submit():
    try:
        os.remove("static/images/image0.jpg")
        shutil.rmtree("static/images/image0.jpg")
        shutil.rmtree("runs")
    except:
        pass
    if request.method == "POST":
        # Get the text input from the form
        address = ""
        user_text = request.form["user_text"]
        address = user_text.strip()
        print("Addressess = ", address)
        image_address = get_image(address)
        # print(image_address)
        predict_image(image_address)
        shutil.copy("runs/segment/predict/image0.jpg", "static/images")

        return redirect("/display")
        # return render_template("index1.html", coordinates="done")

    return render_template("error.html")


@app.route("/display")
def display():
    return render_template("index1.html")


if __name__ == "__main__":
    app.run(debug=True)
